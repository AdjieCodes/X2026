/**
 * Harbor AI callable Cloud Function.
 *
 * This function acts as a secure proxy between the mobile app and the
 * Gemini / Claude API. The API key is stored in Firebase environment
 * secrets and never exposed to the client.
 *
 * Set the secret before deploying:
 *   firebase functions:secrets:set AI_API_KEY
 *
 * Usage from the client:
 *   const result = await httpsCallable(getFunctions(), 'aiComplete')({
 *     system: '...',
 *     messages: [{ role: 'user', content: '...' }],
 *     max_tokens: 300,
 *   });
 *   const text = result.data.text;
 */
import { defineSecret } from "firebase-functions/params";
import { HttpsError, onCall } from "firebase-functions/v2/https";

const aiApiKey = defineSecret("AI_API_KEY");

/** Which model provider to use. Change to 'claude' to use Anthropic instead. */
const PROVIDER: "gemini" | "claude" = "gemini";

// ---------------------------------------------------------------------------
// Request / response types
// ---------------------------------------------------------------------------

interface AIMessage {
  role: "user" | "assistant";
  content: string;
}

interface AIRequest {
  system?: string;
  messages: AIMessage[];
  max_tokens: number;
}

// ---------------------------------------------------------------------------
// Provider implementations
// ---------------------------------------------------------------------------

async function callGemini(
  req: AIRequest,
  apiKey: string,
): Promise<string> {
  const model = "gemini-3.5-flash-lite";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  // Map our messages format to Gemini's format
  const contents = req.messages.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));

  const body: Record<string, unknown> = {
    contents,
    generationConfig: {
      maxOutputTokens: req.max_tokens,
      temperature: 0.7,
    },
  };

  if (req.system) {
    body.systemInstruction = {
      parts: [{ text: req.system }],
    };
  }

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new HttpsError(
      "internal",
      `Gemini API returned ${res.status}: ${errText.slice(0, 200)}`,
    );
  }

  const data: any = await res.json();
  const text =
    data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (typeof text !== "string") {
    throw new HttpsError("internal", "No text in Gemini response.");
  }
  return text.trim();
}

async function callClaude(
  req: AIRequest,
  apiKey: string,
): Promise<string> {
  const url = "https://api.anthropic.com/v1/messages";
  const body: Record<string, unknown> = {
    model: "claude-sonnet-4-20250514",
    max_tokens: req.max_tokens,
    messages: req.messages.map((m) => ({
      role: m.role,
      content: m.content,
    })),
  };

  if (req.system) {
    body.system = req.system;
  }

  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new HttpsError(
      "internal",
      `Claude API returned ${res.status}: ${errText.slice(0, 200)}`,
    );
  }

  const data: any = await res.json();
  const text = data?.content?.[0]?.text;
  if (typeof text !== "string") {
    throw new HttpsError("internal", "No text in Claude response.");
  }
  return text.trim();
}

// ---------------------------------------------------------------------------
// Callable function
// ---------------------------------------------------------------------------

export const aiComplete = onCall(
  {
    secrets: [aiApiKey],
    // Restrict to authenticated users; enforceAppCheck can be added later.
    cors: true,
    maxInstances: 20,
    timeoutSeconds: 60,
    memory: "256MiB",
  },
  async (request) => {
    // 1. Validate auth
    if (!request.auth?.uid) {
      throw new HttpsError(
        "unauthenticated",
        "You must be signed in to use Harbor AI.",
      );
    }

    // 2. Validate payload
    const data = request.data as AIRequest | undefined;
    if (
      !data ||
      !Array.isArray(data.messages) ||
      data.messages.length === 0
    ) {
      throw new HttpsError(
        "invalid-argument",
        "messages must be a non-empty array.",
      );
    }
    for (const m of data.messages) {
      if (!m.role || !m.content) {
        throw new HttpsError(
          "invalid-argument",
          "Each message needs a role and content.",
        );
      }
    }
    const maxTokens = Math.min(
      Math.max(1, data.max_tokens ?? 300),
      2000,
    );

    // 3. Call the provider
    const apiKey = aiApiKey.value();
    if (!apiKey) {
      throw new HttpsError(
        "failed-precondition",
        "AI_API_KEY secret is not set. Run: firebase functions:secrets:set AI_API_KEY",
      );
    }

    const req: AIRequest = {
      system: typeof data.system === "string" ? data.system : undefined,
      messages: data.messages,
      max_tokens: maxTokens,
    };

    const text =
      PROVIDER === "gemini"
        ? await callGemini(req, apiKey)
        : await callClaude(req, apiKey);

    return { text };
  },
);
