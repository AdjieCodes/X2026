/**
 * Firestore chat service (Phase 4).
 *
 * Persists direct messages in Firestore:
 *   chats/{chatId}                           (chat metadata)
 *     participants: [uid1, uid2]
 *     lastMessage: string
 *     lastMessageAt: Timestamp
 *     createdAt: Timestamp
 *   chats/{chatId}/messages/{messageId}      (individual messages)
 *     senderId: string
 *     text: string
 *     createdAt: Timestamp
 *     readBy: string[]
 *
 * Chat IDs are deterministic: the two UIDs sorted and joined with '_',
 * so both participants always reference the same document.
 */
import {
  addDoc,
  collection,
  doc,
  getFirestore,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  type DocumentData,
} from '@react-native-firebase/firestore';
import type { Chat, ChatMessage } from '../../data/types';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Deterministic chat id from two user ids. */
export function chatIdFor(uid1: string, uid2: string): string {
  return uid1 < uid2 ? `${uid1}_${uid2}` : `${uid2}_${uid1}`;
}

function toMillis(value: unknown): number {
  const ts = value as { toMillis?: () => number } | null | undefined;
  return ts && typeof ts.toMillis === 'function' ? ts.toMillis() : 0;
}

function mapMessage(id: string, d: DocumentData): ChatMessage {
  return {
    id,
    fromMe: false, // caller resolves this
    text: typeof d.text === 'string' ? d.text : '',
    createdAt: toMillis(d.createdAt) || Date.now(),
  };
}

// ---------------------------------------------------------------------------
// Chat operations
// ---------------------------------------------------------------------------

const db = () => getFirestore();

/**
 * Subscribe to all chats the user participates in, ordered by most recent
 * message. Returns an unsubscribe function.
 */
export function subscribeChats(
  meId: string,
  onNext: (chats: Chat[]) => void,
  onError: (e: Error) => void,
): () => void {
  const q = query(
    collection(db(), 'chats'),
    where('participants', 'array-contains', meId),
    orderBy('lastMessageAt', 'desc'),
    limit(50),
  );
  return onSnapshot(
    q,
    snap => {
      const chats: Chat[] = snap.docs.map(docSnap => {
        const d = docSnap.data();
        const participants: string[] = Array.isArray(d.participants)
          ? d.participants
          : [];
        const peerId = participants.find(id => id !== meId) ?? '';
        return {
          id: docSnap.id,
          peerId,
          timeLabel: formatTimeLabel(toMillis(d.lastMessageAt)),
          unread: false, // resolved per-message with readBy
          messages: [],
          smartReplies: [],
          typing: false,
        };
      });
      onNext(chats);
    },
    e => onError(e as Error),
  );
}

/**
 * Subscribe to messages in a specific chat. Returns an unsubscribe function.
 */
export function subscribeChatMessages(
  chatId: string,
  meId: string,
  onNext: (messages: ChatMessage[]) => void,
  onError: (e: Error) => void,
): () => void {
  const q = query(
    collection(db(), 'chats', chatId, 'messages'),
    orderBy('createdAt', 'asc'),
    limit(200),
  );
  return onSnapshot(
    q,
    snap => {
      const messages: ChatMessage[] = snap.docs.map(docSnap => {
        const d = docSnap.data();
        const msg = mapMessage(docSnap.id, d);
        msg.fromMe = d.senderId === meId;
        return msg;
      });
      onNext(messages);
    },
    e => onError(e as Error),
  );
}

/**
 * Send a message to a chat. Creates the chat doc if it doesn't exist.
 */
export async function sendChatMessage(
  meId: string,
  peerId: string,
  text: string,
): Promise<void> {
  const clean = text.trim();
  if (!clean) {
    return;
  }
  const chatId = chatIdFor(meId, peerId);
  const chatRef = doc(db(), 'chats', chatId);

  // Upsert the chat document
  try {
    await setDoc(
      chatRef,
      {
        participants: [meId, peerId].sort(),
        lastMessage: clean.slice(0, 200),
        lastMessageAt: serverTimestamp(),
        createdAt: serverTimestamp(),
      },
      { merge: true },
    );
  } catch {
    // Chat may already exist, update instead
    try {
      await updateDoc(chatRef, {
        lastMessage: clean.slice(0, 200),
        lastMessageAt: serverTimestamp(),
      });
    } catch {
      // Ignore: the message add below will still work if rules allow.
    }
  }

  // Add the message
  await addDoc(collection(db(), 'chats', chatId, 'messages'), {
    senderId: meId,
    text: clean,
    createdAt: serverTimestamp(),
    readBy: [meId],
  });
}

/**
 * Mark all messages in a chat as read by the current user.
 */
export async function markChatRead(
  _chatId: string,
  _meId: string,
): Promise<void> {
  // This is a simplified approach: we'd ideally batch-update unread messages.
  // For now, mark read is tracked at the chat level in SocialContext.
  // A full implementation would query unread messages and update each.
}

// ---------------------------------------------------------------------------
// Time formatting
// ---------------------------------------------------------------------------

function formatTimeLabel(epochMs: number): string {
  if (!epochMs) {
    return '';
  }
  const now = Date.now();
  const diff = now - epochMs;
  const mins = Math.floor(diff / 60000);
  if (mins < 1) {
    return 'now';
  }
  if (mins < 60) {
    return `${mins}m`;
  }
  const hours = Math.floor(mins / 60);
  if (hours < 24) {
    return `${hours}h`;
  }
  const date = new Date(epochMs);
  const days = Math.floor(hours / 24);
  if (days < 7) {
    return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][date.getDay()];
  }
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];
  return `${months[date.getMonth()]} ${date.getDate()}`;
}
