/**
 * Firestore social backend service (Phase 4).
 *
 * Persists friends and friend requests:
 *   users/{uid}/friends/{friendUid}         { createdAt: Timestamp }
 *   friendRequests/{fromUid_toUid}          { fromId, toId, state, createdAt }
 */
import {
  collection,
  deleteDoc,
  doc,
  getFirestore,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from '@react-native-firebase/firestore';
import type { FriendRequest } from '../../data/types';

const db = () => getFirestore();

/**
 * Subscribe to the user's friend IDs (users/{meId}/friends).
 */
export function subscribeFriends(
  meId: string,
  onNext: (friendIds: string[]) => void,
  onError: (e: Error) => void,
): () => void {
  const colRef = collection(db(), 'users', meId, 'friends');
  return onSnapshot(
    colRef,
    snap => {
      onNext(snap.docs.map(d => d.id));
    },
    e => onError(e as Error),
  );
}

/**
 * Subscribe to friend requests involving the user (incoming and outgoing).
 */
export function subscribeFriendRequests(
  meId: string,
  onNext: (data: { incoming: FriendRequest[]; requestedIds: string[] }) => void,
  onError: (e: Error) => void,
): () => void {
  const qIn = query(
    collection(db(), 'friendRequests'),
    where('toId', '==', meId),
    where('state', '==', 'pending'),
  );

  const qOut = query(
    collection(db(), 'friendRequests'),
    where('fromId', '==', meId),
    where('state', '==', 'pending'),
  );

  let inList: FriendRequest[] = [];
  let outList: string[] = [];

  const unsubIn = onSnapshot(
    qIn,
    snap => {
      inList = snap.docs.map(d => {
        const data = d.data();
        return {
          id: d.id,
          fromId: data.fromId,
          state: data.state ?? 'pending',
        };
      });
      onNext({ incoming: inList, requestedIds: outList });
    },
    e => onError(e as Error),
  );

  const unsubOut = onSnapshot(
    qOut,
    snap => {
      outList = snap.docs.map(d => d.data().toId as string);
      onNext({ incoming: inList, requestedIds: outList });
    },
    e => onError(e as Error),
  );

  return () => {
    unsubIn();
    unsubOut();
  };
}

/**
 * Send a friend request.
 */
export async function sendFriendRequest(
  meId: string,
  toId: string,
): Promise<string> {
  const reqId = `${meId}_${toId}`;
  const reqRef = doc(db(), 'friendRequests', reqId);
  await setDoc(reqRef, {
    fromId: meId,
    toId,
    state: 'pending',
    createdAt: serverTimestamp(),
  });
  return reqId;
}

/**
 * Cancel a pending friend request sent by me.
 */
export async function cancelFriendRequest(
  meId: string,
  toId: string,
): Promise<void> {
  const reqId = `${meId}_${toId}`;
  await deleteDoc(doc(db(), 'friendRequests', reqId));
}

/**
 * Accept a friend request. Atomically updates the request and creates
 * reciprocal friendship documents in both users' friend subcollections.
 */
export async function acceptFriendRequest(
  requestId: string,
  fromId: string,
  toId: string,
): Promise<void> {
  const batch = writeBatch(db());
  batch.update(doc(db(), 'friendRequests', requestId), {
    state: 'accepted',
  });
  batch.set(doc(db(), 'users', toId, 'friends', fromId), {
    createdAt: serverTimestamp(),
  });
  batch.set(doc(db(), 'users', fromId, 'friends', toId), {
    createdAt: serverTimestamp(),
  });
  await batch.commit();
}

/**
 * Decline a friend request.
 */
export async function declineFriendRequest(requestId: string): Promise<void> {
  await updateDoc(doc(db(), 'friendRequests', requestId), {
    state: 'declined',
  });
}

/**
 * Remove a friend from both users' friend lists.
 */
export async function removeFriend(
  meId: string,
  friendId: string,
): Promise<void> {
  const batch = writeBatch(db());
  batch.delete(doc(db(), 'users', meId, 'friends', friendId));
  batch.delete(doc(db(), 'users', friendId, 'friends', meId));
  await batch.commit();
}
