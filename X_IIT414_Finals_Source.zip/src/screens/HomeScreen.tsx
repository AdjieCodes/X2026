import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  Alert,
  FlatList,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BriefCard } from '../components/feed/BriefCard';
import { ComposerRow } from '../components/feed/ComposerRow';
import { FeedHeader } from '../components/feed/FeedHeader';
import { FeedPostCard } from '../components/feed/FeedPostCard';
import { FeedSkeleton, PostSkeleton } from '../components/feed/FeedSkeleton';
import { StoryRail } from '../components/feed/StoryRail';
import { FeedSummaryCard } from '../components/feed/FeedSummaryCard';
import { Icon } from '../components/Icon';
import { EmptyState, ErrorState, useToast } from '../components/ui';
import { briefCopy } from '../data/social';
import { firstNameOf, type Post } from '../data/types';
import { useTabBarClearance } from '../navigation/insets';
import { useNav } from '../navigation/Navigator';
import { useGoToTab, useScrollToTop } from '../navigation/TabBarContext';
import { useOpenProfile } from '../navigation/useOpenProfile';
import { getOrGenerateFeedSummary, type FeedSummaryData } from '../services/summary';
import {
  useBrief,
  useChats,
  useMe,
  useNotifications,
  usePeople,
  useStories,
} from '../state/SocialContext';
import { useStore } from '../state/StoreContext';
import { colors, fonts } from '../theme';
import { messageOf } from '../utils/errors';

/**
 * The Home tab (SPEC 3.04): composer row, stories rail, Harbor Brief card
 * and the post list under a floating, translucent header. Pull to refresh,
 * load more at the end, and the "all caught up" cap once there is no more.
 */
export function HomeScreen() {
  const nav = useNav();
  const toast = useToast();
  const goToTab = useGoToTab();
  const insets = useSafeAreaInsets();
  const bottom = useTabBarClearance(38);
  const {
    posts,
    feedState,
    feedError,
    hasMore,
    refreshFeed,
    loadMore,
    isMe,
    toggleLike,
    deletePost,
  } = useStore();
  const me = useMe();
  const person = usePeople();
  const { stories, isSeen } = useStories();
  const brief = useBrief();
  const { unreadCount } = useNotifications();
  const { unreadCount: unreadChats } = useChats();
  const openAuthor = useOpenProfile();
  const [briefOpen, setBriefOpen] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const listRef = useRef<FlatList<Post>>(null);

  const [summaryData, setSummaryData] = useState<FeedSummaryData | null>(null);
  const [summaryLoading, setSummaryLoading] = useState(false);

  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const openAskFeed = useCallback(() => nav.push({ name: 'GrokChat' }), [nav]);

  const fetchSummary = useCallback(
    async (force = false) => {
      if (summaryLoading) return;
      setSummaryLoading(true);
      try {
        const res = await getOrGenerateFeedSummary(posts, force);
        if (mounted.current) {
          setSummaryData(res);
        }
      } catch (e) {
        console.log('Error getting summary:', e);
      } finally {
        if (mounted.current) {
          setSummaryLoading(false);
        }
      }
    },
    [posts, summaryLoading],
  );

  // Auto-fetch cached summary on mount and when posts update
  useEffect(() => {
    if (!summaryData && !summaryLoading) {
      fetchSummary(false);
    }
  }, [summaryData, summaryLoading, fetchSummary]);

  const topPad = insets.top + 60;
  const coldLoad = feedState === 'loading' && posts.length === 0;
  const coldError = feedState === 'error' && posts.length === 0;

  const scrollToTop = useCallback(() => {
    listRef.current?.scrollToOffset({ offset: 0, animated: true });
  }, []);
  useScrollToTop('home', scrollToTop);

  // When one of my posts finishes sharing, bring the top of the feed (where
  // it lands) into view. A failed post just disappears.
  const sharing = useRef(new Set<string>());
  useEffect(() => {
    let shared = false;
    for (const p of posts) {
      if (p.pending && isMe(p.authorId)) {
        sharing.current.add(p.id);
      } else if (sharing.current.has(p.id)) {
        sharing.current.delete(p.id);
        shared = true;
      }
    }
    if (shared) {
      scrollToTop();
    }
  }, [posts, isMe, scrollToTop]);

  // An error while posts are already on screen is a toast, not a state.
  const lastError = useRef<string | undefined>(undefined);
  useEffect(() => {
    const current = feedState === 'error' ? feedError : undefined;
    if (current && posts.length > 0 && lastError.current !== current) {
      toast.show(current, { icon: 'warning-circle' });
    }
    lastError.current = current;
  }, [feedState, feedError, posts.length, toast]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await refreshFeed();
    } catch (e) {
      toast.show(messageOf(e, "Couldn't refresh your feed."), {
        icon: 'warning-circle',
      });
    } finally {
      if (mounted.current) {
        setRefreshing(false);
      }
    }
  }, [refreshFeed, toast]);

  const onEndReached = useCallback(async () => {
    if (!hasMore || loadingMore || feedState !== 'ready') {
      return;
    }
    setLoadingMore(true);
    try {
      await loadMore();
    } catch (e) {
      toast.show(messageOf(e, "Couldn't load more posts."), {
        icon: 'warning-circle',
      });
    } finally {
      if (mounted.current) {
        setLoadingMore(false);
      }
    }
  }, [feedState, hasMore, loadMore, loadingMore, toast]);

  const retry = useCallback(() => {
    refreshFeed().catch(e =>
      toast.show(messageOf(e, "Couldn't load your feed."), {
        icon: 'warning-circle',
      }),
    );
  }, [refreshFeed, toast]);

  // ---- navigation ----------------------------------------------------------
  const compose = useCallback(() => {
    if (me.disabled) {
      Alert.alert(
        'Account Disabled',
        'Your account has been disabled by an administrator. You cannot create or publish posts.',
      );
      return;
    }
    nav.push({ name: 'NewPost' }, 'modal');
  }, [me.disabled, nav]);

  const composePhoto = useCallback(() => {
    if (me.disabled) {
      Alert.alert(
        'Account Disabled',
        'Your account has been disabled by an administrator. You cannot create or publish posts.',
      );
      return;
    }
    nav.push({ name: 'NewPost', withPhoto: true }, 'modal');
  }, [me.disabled, nav]);
  const openStory = useCallback(
    (index: number) => nav.push({ name: 'Story', index }, 'fade'),
    [nav],
  );
  const openNotifications = useCallback(
    () => nav.push({ name: 'Notifications' }),
    [nav],
  );
  const openMessages = useCallback(() => nav.push({ name: 'Messages' }), [nav]);

  // ---- Brief ---------------------------------------------------------------
  const { regenerate } = brief;
  const toggleBrief = useCallback(() => setBriefOpen(o => !o), []);
  const refreshBrief = useCallback(() => {
    setBriefOpen(true);
    regenerate().catch(() =>
      toast.show("Couldn't refresh the Brief", { icon: 'warning-circle' }),
    );
  }, [regenerate, toast]);
  const fullBrief = useCallback(() => goToTab('brief'), [goToTab]);

  // ---- post actions (id-based and stable, so memo cards skip renders) -----
  const open = useCallback(
    (postId: string) => nav.push({ name: 'Post', postId }),
    [nav],
  );
  const comment = useCallback(
    (postId: string) => nav.push({ name: 'Post', postId, focusComment: true }),
    [nav],
  );
  const like = useCallback(
    (postId: string) => {
      toggleLike(postId).catch(e =>
        toast.show(messageOf(e, "Couldn't update that like."), {
          icon: 'warning-circle',
        }),
      );
    },
    [toggleLike, toast],
  );
  const share = useCallback(() => toast.show('Link copied'), [toast]);

  // Read through a ref so the More handler stays stable while posts change.
  const postsRef = useRef(posts);
  useEffect(() => {
    postsRef.current = posts;
  }, [posts]);
  const more = useCallback(
    (postId: string) => {
      const post = postsRef.current.find(p => p.id === postId);
      if (!post || !isMe(post.authorId)) {
        toast.show('Post saved');
        return;
      }
      // My own posts: author can Edit or Delete
      Alert.alert('Post Options', 'Choose an action for your post', [
        {
          text: 'Edit Post',
          onPress: () => {
            nav.push({
              name: 'NewPost',
              editPostId: post.id,
              initialText: post.text,
            });
          },
        },
        {
          text: 'Delete Post',
          style: 'destructive',
          onPress: () => {
            Alert.alert(
              'Delete Post?',
              'Are you sure you want to delete this post? This cannot be undone.',
              [
                { text: 'Cancel', style: 'cancel' },
                {
                  text: 'Delete',
                  style: 'destructive',
                  onPress: () => {
                    deletePost(postId).catch(e =>
                      toast.show(messageOf(e, "Couldn't delete the post."), {
                        icon: 'warning-circle',
                      }),
                    );
                  },
                },
              ],
            );
          },
        },
        { text: 'Cancel', style: 'cancel' },
      ]);
    },
    [deletePost, isMe, nav, toast],
  );

  const renderItem = useCallback(
    ({ item }: { item: Post }) => (
      <FeedPostCard
        post={item}
        author={person(item.authorId)}
        onOpen={open}
        onComment={comment}
        onLike={like}
        onDoubleTapLike={like}
        onShare={share}
        onMore={more}
        onAuthor={openAuthor}
      />
    ),
    [person, open, comment, like, share, more, openAuthor],
  );

  const header = useMemo(
    () => (
      <>
        {me.disabled ? (
          <View style={styles.disabledNoticeBanner}>
            <Icon
              name="warning-circle"
              size={22}
              color="#DC2626"
              weight="fill"
            />
            <View style={styles.disabledNoticeContent}>
              <Text style={styles.disabledNoticeTitle}>Account Disabled</Text>
              <Text style={styles.disabledNoticeText}>
                Your account was disabled by an administrator. You can view
                posts, but creating new posts is restricted.
              </Text>
            </View>
          </View>
        ) : null}

        <View style={styles.feedTabs}>
          <View style={styles.feedTab}><Text style={styles.feedTabActive}>For you</Text><View style={styles.feedTabIndicator} /></View>
          <View style={styles.feedTab}><Text style={styles.feedTabText}>Following</Text></View>
        </View>

        <ComposerRow
          firstName={firstNameOf(me.name)}
          photoUrl={me.photoUrl}
          name={me.name}
          onCompose={compose}
          onComposePhoto={composePhoto}
        />

        <FeedSummaryCard
          summary={summaryData}
          loading={summaryLoading}
          onSummarize={fetchSummary}
          onAskFeed={openAskFeed}
        />
      </>
    ),
    [
      me.name,
      me.photoUrl,
      me.disabled,
      summaryData,
      summaryLoading,
      fetchSummary,
      openAskFeed,
      goToTab,
      compose,
      composePhoto,
      stories,
      isSeen,
      person,
      openStory,
      brief.enabled,
      brief.today,
      brief.loading,
      briefOpen,
      toggleBrief,
      refreshBrief,
      fullBrief,
    ],
  );

  const empty = coldLoad ? (
    <FeedSkeleton />
  ) : coldError ? (
    <View style={styles.section}>
      <ErrorState
        title="Couldn't load your feed"
        message={feedError ?? 'Check your connection and try again.'}
        onRetry={retry}
      />
    </View>
  ) : (
    <View style={styles.section}>
      <EmptyState
        icon="users"
        title="Your feed is quiet"
        body="Posts from your friends show up here."
        actionLabel="Create post"
        onAction={compose}
      />
    </View>
  );

  const footer =
    posts.length === 0 ? undefined : loadingMore ? (
      <PostSkeleton />
    ) : hasMore ? undefined : (
      <View style={styles.endCap}>
        <Text style={styles.endText}>
          You're all caught up from the last 24 hours.
        </Text>
      </View>
    );

  return (
    <View style={styles.flex}>
      <FlatList
        ref={listRef}
        data={posts}
        keyExtractor={keyOf}
        renderItem={renderItem}
        ListHeaderComponent={header}
        ListEmptyComponent={empty}
        ListFooterComponent={footer}
        onEndReached={onEndReached}
        onEndReachedThreshold={0.6}
        contentContainerStyle={{ paddingTop: topPad, paddingBottom: bottom }}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews
        initialNumToRender={4}
        windowSize={7}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.muted}
            colors={[colors.accent]}
            progressViewOffset={topPad}
          />
        }
      />
      <FeedHeader
        unreadCount={unreadCount}
        unreadMessages={unreadChats > 0}
        onNotifications={openNotifications}
        onMessages={openMessages}
        onAskFeed={openAskFeed}
      />
    </View>
  );
}

const keyOf = (p: Post) => p.id;

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: colors.bg },
  feedTabs: { height: 48, flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: colors.line, marginBottom: 2 },
  feedTab: { flex: 1, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  feedTabActive: { fontFamily: fonts.semibold, fontSize: 15, color: colors.ink },
  feedTabText: { fontFamily: fonts.regular, fontSize: 15, color: colors.muted },
  feedTabIndicator: { position: 'absolute', bottom: 0, width: 58, height: 4, borderRadius: 4, backgroundColor: colors.accent },
  disabledNoticeBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: '#FEF2F2',
    borderWidth: 1,
    borderColor: '#FCA5A5',
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
    marginHorizontal: 16,
    marginTop: 8,
    marginBottom: 6,
  },
  disabledNoticeContent: {
    flex: 1,
  },
  disabledNoticeTitle: {
    fontFamily: fonts.semibold,
    fontSize: 14,
    color: '#991B1B',
    marginBottom: 2,
  },
  disabledNoticeText: {
    fontFamily: fonts.regular,
    fontSize: 12.5,
    lineHeight: 17,
    color: '#7F1D1D',
  },
  section: { borderTopWidth: 8, borderTopColor: colors.fill },
  endCap: {
    borderTopWidth: 8,
    borderTopColor: colors.fill,
    paddingVertical: 28,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  endText: {
    fontFamily: fonts.regular,
    fontSize: 14,
    color: colors.muted,
    textAlign: 'center',
  },
});
