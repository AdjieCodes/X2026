/**
 * App-wide switches.
 *
 * DEMO_MODE: when true (the default for teaching/demos), Harbor needs no backend
 * (seed images still load from picsum.photos, so keep a network connection).
 * Auth AND data are local: any valid email plus an 8+ character password
 * signs in (as the demo user with id 'me'), and the feed, comments, follows,
 * activity and settings come from the seeded mock content in
 * src/data/mock.ts, kept in memory. Nothing touches Firebase.
 *
 * When false, auth uses Firebase Auth and data lives in Firestore + Cloud Storage
 * (see src/services/backend/firebase.ts and FIREBASE_SETUP.md).
 */
export const DEMO_MODE = false;

/**
 * Direct Gemini API key for local development or when Cloud Functions are not deployed.
 * If set, AI calls (Harbor Brief, Ask Harbor, Polish, Comment summaries) will call
 * Google AI Studio directly with this key.
 */
export const GEMINI_API_KEY =
  'AQ.Ab8RN6L16uXu2lH6HFlfVyohaEVYsabVEOW3vZY_nI7-QYRa_w';

/** Posts per feed page. The feed is one realtime query whose window grows by this much on loadMore. */
export const FEED_PAGE_SIZE = 20;
