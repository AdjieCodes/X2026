import React from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { Icon } from '../Icon';
import { colors, fonts } from '../../theme';
import type { FeedSummaryData } from '../../services/summary';

type Props = {
  summary: FeedSummaryData | null;
  loading: boolean;
  onSummarize: (force?: boolean) => void;
  onAskFeed?: () => void;
};

export function FeedSummaryCard({
  summary,
  loading,
  onSummarize,
  onAskFeed,
}: Props) {
  const formatTime = (ms?: number) => {
    if (!ms) return 'Just now';
    const sec = Math.floor((Date.now() - ms) / 1000);
    if (sec < 60) return 'Just now';
    const min = Math.floor(sec / 60);
    if (min < 60) return `${min}m ago`;
    const hrs = Math.floor(min / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return new Date(ms).toLocaleDateString([], {
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        <View style={styles.titleRow}>
          <View style={styles.iconCircle}>
            <Icon name="sparkle" size={16} color="#7C3AED" weight="fill" />
          </View>
          <View>
            <Text style={styles.title}>AI Feed Summary</Text>
            <Text style={styles.subtitle}>
              {summary
                ? `${summary.isCached ? 'Cached' : 'Generated'} • ${formatTime(
                    summary.updatedAt,
                  )}`
                : 'Catch up on recent posts'}
            </Text>
          </View>
        </View>

        <View style={styles.actionRow}>
          {onAskFeed ? (
            <TouchableOpacity
              style={styles.askBtn}
              activeOpacity={0.8}
              onPress={onAskFeed}
            >
              <Icon name="chat-circle-dots" size={14} color="#4F46E5" />
              <Text style={styles.askBtnText}>Ask Feed</Text>
            </TouchableOpacity>
          ) : null}

          <TouchableOpacity
            style={[styles.summarizeBtn, loading && styles.disabledBtn]}
            disabled={loading}
            onPress={() => onSummarize(true)}
            activeOpacity={0.8}
          >
            {loading ? (
              <ActivityIndicator size="small" color="#7C3AED" />
            ) : (
              <>
                <Icon name="arrow-clockwise" size={14} color="#7C3AED" />
                <Text style={styles.summarizeText}>
                  {summary ? 'Refresh' : 'Summarize'}
                </Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </View>

      {summary ? (
        <View style={styles.body}>
          <Text style={styles.summaryText}>{summary.text}</Text>
          <View style={styles.footer}>
            <View style={styles.badge}>
              <Icon name="clipboard-text" size={12} color="#6B7280" />
              <Text style={styles.badgeText}>
                {summary.postCount} recent posts
              </Text>
            </View>
            <Text style={styles.cacheNotice}>
              Cached in Firestore (summaries/latest)
            </Text>
          </View>
        </View>
      ) : (
        <View style={styles.emptyPrompt}>
          <Text style={styles.emptyText}>
            Tap "Summarize" to get an AI summary of community posts.
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FAF5FF',
    marginHorizontal: 16,
    marginVertical: 10,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E9D5FF',
    padding: 14,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: 8,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  iconCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F3E8FF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontFamily: fonts.semibold,
    fontSize: 15,
    color: '#581C87',
  },
  subtitle: {
    fontFamily: fonts.regular,
    fontSize: 12,
    color: '#7E22CE',
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  askBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#EEF2FF',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#C7D2FE',
  },
  askBtnText: {
    fontFamily: fonts.medium,
    fontSize: 12,
    color: '#4F46E5',
  },
  summarizeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#FFFFFF',
    paddingVertical: 6,
    paddingHorizontal: 11,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#DDD6FE',
  },
  disabledBtn: {
    opacity: 0.6,
  },
  summarizeText: {
    fontFamily: fonts.medium,
    fontSize: 12,
    color: '#7C3AED',
  },
  body: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: '#F3E8FF',
  },
  summaryText: {
    fontFamily: fonts.regular,
    fontSize: 13.5,
    lineHeight: 20,
    color: '#3B0764',
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#FFFFFF',
    paddingVertical: 2,
    paddingHorizontal: 6,
    borderRadius: 6,
  },
  badgeText: {
    fontFamily: fonts.regular,
    fontSize: 11,
    color: '#6B7280',
  },
  cacheNotice: {
    fontFamily: fonts.regular,
    fontSize: 11,
    color: '#9333EA',
  },
  emptyPrompt: {
    marginTop: 8,
  },
  emptyText: {
    fontFamily: fonts.regular,
    fontSize: 13,
    color: '#6B21A8',
  },
});
