import { doc, getDoc, setDoc, serverTimestamp, db } from './firebase';

export type AIInsights = {
  topics: string[];
  mood: 'positive' | 'neutral' | 'negative';
  summary: string;
  updatedAt?: number;
};

const GEMINI_API_KEY =
  import.meta.env.VITE_GEMINI_API_KEY ||
  'AQ.Ab8RN6L16uXu2lH6HFlfVyohaEVYsabVEOW3vZY_nI7-QYRa_w';

/**
 * Fetch or generate community AI Insights.
 * Uses Gemini API with structured JSON output, saved in insights/latest.
 */
export async function fetchOrGenerateInsights(
  posts: Array<{ text: string }>,
  forceRefresh = false
): Promise<AIInsights> {
  const insightsRef = doc(db, 'insights', 'latest');

  // 1. Check existing insights
  if (!forceRefresh) {
    try {
      const snap = await getDoc(insightsRef);
      if (snap.exists()) {
        const d = snap.data();
        const updatedMs = d?.updatedAt?.toMillis
          ? d.updatedAt.toMillis()
          : typeof d?.updatedAt === 'number'
          ? d.updatedAt
          : Date.now();
        return {
          topics: Array.isArray(d?.topics) ? d.topics : [],
          mood: d?.mood || 'neutral',
          summary: d?.summary || '',
          updatedAt: updatedMs,
        };
      }
    } catch (e) {
      console.log('Error reading insights/latest:', e);
    }
  }

  // 2. Generate new insights using Gemini
  const sample = posts.slice(0, 25);
  const postsBlock = sample.map((p, idx) => `[Post ${idx + 1}]: ${p.text}`).join('\n');

  const systemInstruction = `You are an AI Analytics Engine for a community social network.
Analyze the provided community posts and output a strictly valid JSON object with the following schema:
{
  "topics": ["string", "string", "string"],
  "mood": "positive" | "neutral" | "negative",
  "summary": "2-sentence executive summary of the community sentiment and discussion"
}
Ensure topics are concise tags (1-3 words each). Do NOT output markdown code fences or extra text, ONLY the raw JSON object.`;

  let result: AIInsights | null = null;

  if (GEMINI_API_KEY) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent?key=${GEMINI_API_KEY}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemInstruction }] },
          contents: [
            {
              parts: [
                {
                  text: `Analyze these community posts and return structured JSON:\n\n${postsBlock || 'No posts available.'}`,
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.3,
            maxOutputTokens: 400,
            responseMimeType: 'application/json',
          },
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const rawJson = data?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (rawJson) {
          const parsed = JSON.parse(rawJson.replace(/```json|```/g, '').trim());
          result = {
            topics: parsed.topics || [],
            mood: parsed.mood || 'neutral',
            summary: parsed.summary || '',
          };
        }
      }
    } catch (e) {
      console.log('Error generating AI insights:', e);
    }
  }

  // Fallback if AI generation failed or empty
  if (!result) {
    result = {
      topics: ['Community Updates', 'Daily Highlights', 'Creative Work'],
      mood: 'positive',
      summary:
        'Community members are actively engaging and sharing creative projects and outdoor adventures with positive sentiment.',
    };
  }

  // 3. Save to Firestore insights/latest
  try {
    await setDoc(insightsRef, {
      ...result,
      updatedAt: serverTimestamp(),
    });
  } catch (e) {
    console.log('Error writing insights/latest:', e);
  }

  return {
    ...result,
    updatedAt: Date.now(),
  };
}
