import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  type User as FirebaseUser,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  collection,
  onSnapshot,
  query,
  orderBy,
  deleteDoc,
  updateDoc,
  setDoc,
  serverTimestamp,
  Timestamp,
} from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyAUyHd4I4RWusByfAdCnXAxkFWsN8OOZVs",
  authDomain: "x-2026-letran.firebaseapp.com",
  projectId: "x-2026-letran",
  storageBucket: "x-2026-letran.firebasestorage.app",
  messagingSenderId: "807224797110",
  appId: "1:807224797110:web:503ec0111c1ba100938317",
  measurementId: "G-3VK1Z2S1D9"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getFirestore(app);

export {
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  doc,
  getDoc,
  collection,
  onSnapshot,
  query,
  orderBy,
  deleteDoc,
  updateDoc,
  setDoc,
  serverTimestamp,
  Timestamp,
  type FirebaseUser,
};
