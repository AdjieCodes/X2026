import React, { useEffect, useState } from 'react';
import {
  auth,
  signOut,
  onAuthStateChanged,
  doc,
  getDoc,
  db,
  type FirebaseUser,
} from './firebase';
import { LoginPage } from './pages/LoginPage';
import { DashboardPage } from './pages/DashboardPage';
import { PostsPage } from './pages/PostsPage';
import { UsersPage } from './pages/UsersPage';

type Tab = 'dashboard' | 'posts' | 'users';

export function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [checkingAuth, setCheckingAuth] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async currentUser => {
      if (currentUser) {
        const isDevAdmin =
          currentUser.email?.toLowerCase() === 'adrianjose.desanagustin@letran.edu.ph' ||
          currentUser.uid === 'RS3DpakpMtW99TSqRzytBc4mskv2';

        // Verify admin collection doc
        try {
          const adminDoc = await getDoc(doc(db, 'admins', currentUser.uid));
          if (adminDoc.exists() || isDevAdmin) {
            setUser(currentUser);
            setIsAdmin(true);
          } else {
            await signOut(auth);
            setUser(null);
            setIsAdmin(false);
          }
        } catch (e) {
          if (isDevAdmin) {
            setUser(currentUser);
            setIsAdmin(true);
          } else {
            console.error('Error verifying admin status:', e);
            setUser(null);
            setIsAdmin(false);
          }
        }
      } else {
        setUser(null);
        setIsAdmin(null);
      }
      setCheckingAuth(false);
    });
    return unsub;
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
    setIsAdmin(null);
  };

  if (checkingAuth) {
    return (
      <div style={{ display: 'flex', height: '100vh', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ color: 'var(--muted)', fontWeight: 600 }}>Loading Administrator Portal...</p>
      </div>
    );
  }

  if (!user || !isAdmin) {
    return <LoginPage onLoginSuccess={u => { setUser(u); setIsAdmin(true); }} />;
  }

  return (
    <div className="app-container">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="brand-icon">𝕏</div>
          <div className="brand-text">
            <h2>X</h2>
            <span>Administrator</span>
          </div>
        </div>

        <nav className="nav-menu">
          <button
            className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveTab('dashboard')}
          >
            📊 Dashboard & AI Insights
          </button>
          <button
            className={`nav-item ${activeTab === 'posts' ? 'active' : ''}`}
            onClick={() => setActiveTab('posts')}
          >
            📝 Post Moderation
          </button>
          <button
            className={`nav-item ${activeTab === 'users' ? 'active' : ''}`}
            onClick={() => setActiveTab('users')}
          >
            👥 User Management
          </button>
        </nav>

        <div className="sidebar-footer">
          <div className="admin-profile">
            {user.photoURL ? (
              <img src={user.photoURL} alt={user.displayName || 'Admin'} className="admin-avatar" />
            ) : (
              <div
                className="admin-avatar"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 700,
                  color: '#2563EB',
                }}
              >
                {user.displayName?.[0] || 'A'}
              </div>
            )}
            <div className="admin-info">
              <h4>{user.displayName || 'Administrator'}</h4>
              <p>{user.email}</p>
            </div>
          </div>
          <button className="logout-btn" onClick={handleLogout} title="Log Out">
            🚪
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="main-content">
        <header className="topbar">
          <div className="page-title">
            <h1>
              {activeTab === 'dashboard' && 'Dashboard Overview'}
              {activeTab === 'posts' && 'Post Moderation'}
              {activeTab === 'users' && 'User Management'}
            </h1>
            <p>
              {activeTab === 'dashboard' && 'Community metrics, activity, and real-time AI Insights'}
              {activeTab === 'posts' && 'Moderate and delete community posts in real time'}
              {activeTab === 'users' && 'Manage user accounts and toggle posting privileges'}
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span
              style={{
                fontSize: '12px',
                fontWeight: 600,
                color: '#16A34A',
                background: '#DCFCE7',
                padding: '4px 10px',
                borderRadius: '12px',
              }}
            >
              ● Connected: x-2026-letran
            </span>
            <button
              onClick={handleLogout}
              style={{
                fontSize: '13px',
                fontWeight: 600,
                color: 'var(--muted)',
                padding: '6px 12px',
                border: '1px solid var(--border)',
                borderRadius: '8px',
                background: '#FFFFFF',
              }}
            >
              Log Out
            </button>
          </div>
        </header>

        {activeTab === 'dashboard' && <DashboardPage />}
        {activeTab === 'posts' && <PostsPage />}
        {activeTab === 'users' && <UsersPage />}
      </main>
    </div>
  );
}
