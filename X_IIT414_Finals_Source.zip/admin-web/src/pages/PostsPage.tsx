import React, { useEffect, useState } from 'react';
import {
  collection,
  onSnapshot,
  query,
  orderBy,
  deleteDoc,
  doc,
  db,
} from '../firebase';

type PostItem = {
  id: string;
  authorId?: string;
  authorName?: string;
  authorPhotoUrl?: string;
  text: string;
  imageUrl?: string;
  createdAt: any;
};

export function PostsPage() {
  const [posts, setPosts] = useState<PostItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [postToDelete, setPostToDelete] = useState<PostItem | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      q,
      snap => {
        const list: PostItem[] = [];
        snap.forEach(docSnap => {
          const d = docSnap.data();
          list.push({
            id: docSnap.id,
            authorId: d.authorId,
            authorName: d.authorName || 'Community Member',
            authorPhotoUrl: d.authorPhotoUrl || d.authorPhoto,
            text: d.text || '',
            imageUrl: d.imageUrl,
            createdAt: d.createdAt,
          });
        });
        setPosts(list);
        setLoading(false);
      },
      err => {
        console.error('Error fetching posts:', err);
        setLoading(false);
      }
    );
    return unsub;
  }, []);

  const confirmDelete = async () => {
    if (!postToDelete) return;
    setDeletingId(postToDelete.id);
    try {
      await deleteDoc(doc(db, 'posts', postToDelete.id));
      setPostToDelete(null);
    } catch (err) {
      console.error('Failed to delete post:', err);
      alert('Failed to delete post. Check permissions.');
    } finally {
      setDeletingId(null);
    }
  };

  const formatTimestamp = (createdAt: any) => {
    if (!createdAt) return 'Recent';
    const ms = createdAt?.toMillis ? createdAt.toMillis() : typeof createdAt === 'number' ? createdAt : null;
    if (!ms) return 'Recent';
    return new Date(ms).toLocaleString([], {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="content-body">
      <div className="table-card">
        <div className="table-header">
          <h3>Community Post Moderation ({posts.length} posts)</h3>
          <span style={{ fontSize: '13px', color: 'var(--muted)' }}>
            Real-time synchronization with Android mobile feed
          </span>
        </div>

        {loading ? (
          <div style={{ padding: '32px', textAlign: 'center', color: 'var(--muted)' }}>
            Loading community posts...
          </div>
        ) : posts.length === 0 ? (
          <div style={{ padding: '32px', textAlign: 'center', color: 'var(--muted)' }}>
            No posts found in the community feed.
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Author</th>
                <th>Post Content</th>
                <th>Date Published</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {posts.map(post => (
                <tr key={post.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      {post.authorPhotoUrl ? (
                        <img
                          src={post.authorPhotoUrl}
                          alt={post.authorName}
                          style={{ width: '32px', height: '32px', borderRadius: '16px', objectFit: 'cover' }}
                        />
                      ) : (
                        <div
                          style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: '16px',
                            background: '#E2E8F0',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontWeight: 600,
                            fontSize: '12px',
                          }}
                        >
                          {post.authorName?.[0] || 'U'}
                        </div>
                      )}
                      <div>
                        <div style={{ fontWeight: 600, fontSize: '13px' }}>{post.authorName}</div>
                        <div style={{ fontSize: '11px', color: 'var(--muted)' }}>ID: {post.authorId?.slice(0, 8)}...</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <div style={{ maxWidth: '420px', lineHeight: '20px' }}>
                      {post.text}
                      {post.imageUrl && (
                        <div style={{ marginTop: '6px' }}>
                          <img
                            src={post.imageUrl}
                            alt="Attachment"
                            style={{ height: '50px', borderRadius: '6px', objectFit: 'cover' }}
                          />
                        </div>
                      )}
                    </div>
                  </td>
                  <td style={{ color: 'var(--muted)', fontSize: '13px' }}>
                    {formatTimestamp(post.createdAt)}
                  </td>
                  <td>
                    <button
                      className="btn-danger"
                      onClick={() => setPostToDelete(post)}
                      disabled={deletingId === post.id}
                    >
                      {deletingId === post.id ? 'Deleting...' : 'Delete'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Confirmation Modal */}
      {postToDelete && (
        <div
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 100,
          }}
        >
          <div
            style={{
              background: '#FFFFFF',
              borderRadius: '16px',
              padding: '24px 28px',
              maxWidth: '440px',
              width: '90%',
              boxShadow: '0 20px 25px -5px rgba(0,0,0,0.2)',
            }}
          >
            <h3 style={{ fontSize: '18px', fontWeight: 700, color: '#991B1B', marginBottom: '8px' }}>
              Confirm Post Deletion
            </h3>
            <p style={{ fontSize: '14px', lineHeight: '22px', color: 'var(--ink)', marginBottom: '16px' }}>
              Are you sure you want to delete this post by <strong>{postToDelete.authorName}</strong>?
              <br />
              <em>"{postToDelete.text.slice(0, 90)}..."</em>
            </p>
            <p style={{ fontSize: '12px', color: '#B91C1C', marginBottom: '20px' }}>
              ⚠️ The deleted post will disappear from the Android mobile feed in real time.
            </p>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
              <button
                style={{
                  padding: '8px 16px',
                  borderRadius: '8px',
                  border: '1px solid var(--border)',
                  fontWeight: 600,
                  fontSize: '13px',
                }}
                onClick={() => setPostToDelete(null)}
              >
                Cancel
              </button>
              <button
                style={{
                  padding: '8px 16px',
                  borderRadius: '8px',
                  background: '#DC2626',
                  color: 'white',
                  fontWeight: 600,
                  fontSize: '13px',
                }}
                onClick={confirmDelete}
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
