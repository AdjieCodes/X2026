import React, { useEffect, useState } from 'react';
import {
  collection,
  onSnapshot,
  query,
  orderBy,
  db,
} from '../firebase';
import { fetchOrGenerateInsights, type AIInsights } from '../ai';

export function DashboardPage() {
  const [userCount, setUserCount] = useState<number>(0);
  const [postCount, setPostCount] = useState<number>(0);
  const [todayPostCount, setTodayPostCount] = useState<number>(0);
  const [posts, setPosts] = useState<Array<{ id: string; text: string; createdAt: any }>>([]);
  const [insights, setInsights] = useState<AIInsights | null>(null);
  const [insightsLoading, setInsightsLoading] = useState<boolean>(false);

  // Subscribe to users count
  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'users'), snap => {
      setUserCount(snap.size);
    });
    return unsub;
  }, []);

  // Subscribe to posts count and calculate posts created today
  useEffect(() => {
    const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, snap => {
      setPostCount(snap.size);

      // Start of today midnight
      const now = new Date();
      const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

      let todayCount = 0;
      const loadedPosts: Array<{ id: string; text: string; createdAt: any }> = [];

      snap.forEach(docSnap => {
        const d = docSnap.data();
        loadedPosts.push({ id: docSnap.id, text: d.text || '', createdAt: d.createdAt });

        const postMs = d.createdAt?.toMillis
          ? d.createdAt.toMillis()
          : typeof d.createdAt === 'number'
          ? d.createdAt
          : null;

        if (postMs && postMs >= startOfDay) {
          todayCount++;
        }
      });

      setTodayPostCount(todayCount);
      setPosts(loadedPosts);
    });
    return unsub;
  }, []);

  // Load insights
  useEffect(() => {
    if (posts.length > 0 && !insights && !insightsLoading) {
      handleRefreshInsights(false);
    }
  }, [posts.length]);

  const handleRefreshInsights = async (force = true) => {
    setInsightsLoading(true);
    try {
      const res = await fetchOrGenerateInsights(posts, force);
      setInsights(res);
    } catch (e) {
      console.error('Failed to refresh AI insights:', e);
    } finally {
      setInsightsLoading(false);
    }
  };

  const formatTimeAgo = (ms?: number) => {
    if (!ms) return 'Just now';
    const sec = Math.floor((Date.now() - ms) / 1000);
    if (sec < 60) return 'Just now';
    const min = Math.floor(sec / 60);
    if (min < 60) return `${min}m ago`;
    const hrs = Math.floor(min / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return new Date(ms).toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="content-body">
      {/* Stat Cards */}
      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-icon" style={{ background: '#EFF6FF', color: '#2563EB' }}>
            👥
          </div>
          <div className="stat-info">
            <span>Total Community Users</span>
            <h3>{userCount}</h3>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: '#FAF5FF', color: '#7C3AED' }}>
            📝
          </div>
          <div className="stat-info">
            <span>Total Posts Published</span>
            <h3>{postCount}</h3>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon" style={{ background: '#ECFDF5', color: '#059669' }}>
            ⚡
          </div>
          <div className="stat-info">
            <span>Posts Created Today</span>
            <h3>{todayPostCount}</h3>
          </div>
        </div>
      </div>

      {/* AI Insights Panel */}
      <div className="ai-insights-panel">
        <div className="ai-header">
          <div className="ai-title-wrap">
            <span className="ai-badge">GEMINI AI</span>
            <h3>Community AI Insights & Sentiment</h3>
          </div>
          <button
            className="refresh-ai-btn"
            onClick={() => handleRefreshInsights(true)}
            disabled={insightsLoading}
          >
            {insightsLoading ? 'Analyzing Feed...' : '⚡ Refresh AI Insights'}
          </button>
        </div>

        <div className="ai-meta-row">
          <div>
            <span style={{ fontSize: '12px', fontWeight: 600, color: '#6D28D9', marginRight: '8px' }}>
              OVERALL MOOD:
            </span>
            <span className={`mood-pill mood-${insights?.mood || 'neutral'}`}>
              {insights?.mood === 'positive' && '😊 Positive'}
              {insights?.mood === 'neutral' && '😐 Neutral'}
              {insights?.mood === 'negative' && '😟 Negative'}
            </span>
          </div>

          <div style={{ fontSize: '12px', color: '#7C3AED' }}>
            Last updated: {formatTimeAgo(insights?.updatedAt)} • Saved in <code>insights/latest</code>
          </div>
        </div>

        <div style={{ marginTop: '10px' }}>
          <span style={{ fontSize: '12px', fontWeight: 600, color: '#6D28D9', display: 'block', marginBottom: '6px' }}>
            TRENDING COMMUNITY TOPICS:
          </span>
          <div className="topics-cloud">
            {insights?.topics && insights.topics.length > 0 ? (
              insights.topics.map((t, idx) => (
                <span key={idx} className="topic-tag">
                  #{t}
                </span>
              ))
            ) : (
              <span className="topic-tag">Analyzing topics...</span>
            )}
          </div>
        </div>

        {insights?.summary && (
          <div className="ai-summary-text">
            <strong>Executive AI Summary: </strong>
            {insights.summary}
          </div>
        )}
      </div>
    </div>
  );
}
