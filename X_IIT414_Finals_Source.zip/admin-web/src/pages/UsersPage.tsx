import React, { useEffect, useState } from 'react';
import {
  collection,
  onSnapshot,
  updateDoc,
  doc,
  db,
} from '../firebase';

type UserItem = {
  id: string;
  name: string;
  email?: string;
  handle?: string;
  photoUrl?: string;
  createdAt?: any;
  joinedAt?: any;
  disabled?: boolean;
};

export function UsersPage() {
  const [users, setUsers] = useState<UserItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, 'users'),
      snap => {
        const list: UserItem[] = [];
        snap.forEach(docSnap => {
          const d = docSnap.data();
          list.push({
            id: docSnap.id,
            name: d.displayName || d.name || 'User',
            email: d.email || `${d.handle || docSnap.id}@gmail.com`,
            handle: d.handle,
            photoUrl: d.photoURL || d.photoUrl,
            createdAt: d.createdAt,
            joinedAt: d.joinedAt,
            disabled: !!d.disabled,
          });
        });
        setUsers(list);
        setLoading(false);
      },
      err => {
        console.error('Error fetching users:', err);
        setLoading(false);
      }
    );
    return unsub;
  }, []);

  const toggleUserStatus = async (user: UserItem) => {
    setUpdatingId(user.id);
    const newStatus = !user.disabled;
    try {
      await updateDoc(doc(db, 'users', user.id), {
        disabled: newStatus,
      });
    } catch (err) {
      console.error('Failed to update user status:', err);
      alert('Failed to update user status. Check permissions.');
    } finally {
      setUpdatingId(null);
    }
  };

  const formatDateJoined = (createdAt: any, joinedAt: any) => {
    const time = createdAt || joinedAt;
    if (!time) return 'Recently';
    const ms = time?.toMillis ? time.toMillis() : typeof time === 'number' ? time : null;
    if (!ms) return 'Recently';
    return new Date(ms).toLocaleDateString([], {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="content-body">
      <div className="table-card">
        <div className="table-header">
          <h3>Community User Management ({users.length} registered users)</h3>
          <span style={{ fontSize: '13px', color: 'var(--muted)' }}>
            Disabling a user blocks post creation and displays a notice on their phone
          </span>
        </div>

        {loading ? (
          <div style={{ padding: '32px', textAlign: 'center', color: 'var(--muted)' }}>
            Loading users...
          </div>
        ) : users.length === 0 ? (
          <div style={{ padding: '32px', textAlign: 'center', color: 'var(--muted)' }}>
            No users registered in Firestore.
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>User Profile</th>
                <th>Email Address</th>
                <th>Date Joined</th>
                <th>Status</th>
                <th>Moderation Action</th>
              </tr>
            </thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      {u.photoUrl ? (
                        <img
                          src={u.photoUrl}
                          alt={u.name}
                          style={{ width: '36px', height: '36px', borderRadius: '18px', objectFit: 'cover' }}
                        />
                      ) : (
                        <div
                          style={{
                            width: '36px',
                            height: '36px',
                            borderRadius: '18px',
                            background: '#E2E8F0',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontWeight: 600,
                            fontSize: '13px',
                          }}
                        >
                          {u.name?.[0] || 'U'}
                        </div>
                      )}
                      <div>
                        <div style={{ fontWeight: 600, fontSize: '14px' }}>{u.name}</div>
                        <div style={{ fontSize: '11px', color: 'var(--muted)' }}>UID: {u.id.slice(0, 8)}...</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ color: 'var(--muted)', fontSize: '13px' }}>
                    {u.email}
                  </td>
                  <td style={{ color: 'var(--muted)', fontSize: '13px' }}>
                    {formatDateJoined(u.createdAt, u.joinedAt)}
                  </td>
                  <td>
                    <span className={`status-badge ${u.disabled ? 'status-disabled' : 'status-active'}`}>
                      {u.disabled ? '🔴 Disabled' : '🟢 Active'}
                    </span>
                  </td>
                  <td>
                    <button
                      className={`btn-toggle ${u.disabled ? 'enable' : 'disable'}`}
                      onClick={() => toggleUserStatus(u)}
                      disabled={updatingId === u.id}
                    >
                      {updatingId === u.id
                        ? 'Updating...'
                        : u.disabled
                        ? 'Enable User'
                        : 'Disable User'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
