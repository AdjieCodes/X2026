import React, { useState } from 'react';
import {
  auth,
  googleProvider,
  signInWithPopup,
  signOut,
  doc,
  getDoc,
  db,
  type FirebaseUser,
} from '../firebase';

type Props = {
  onLoginSuccess: (user: FirebaseUser) => void;
};

export function LoginPage({ onLoginSuccess }: Props) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;

      // Check if user's UID is in the admins collection (with local dev bypass)
      const isDevAdmin =
        user.email?.toLowerCase() === 'adrianjose.desanagustin@letran.edu.ph' ||
        user.uid === 'RS3DpakpMtW99TSqRzytBc4mskv2';

      let hasAdminDoc = false;
      try {
        const adminDocRef = doc(db, 'admins', user.uid);
        const adminDocSnap = await getDoc(adminDocRef);
        hasAdminDoc = adminDocSnap.exists();
      } catch (e) {
        console.warn('Could not read admins collection:', e);
      }

      if (!hasAdminDoc && !isDevAdmin) {
        await signOut(auth);
        setError(
          `Access Denied: The account (${user.email}) is not in the 'admins' collection. UID: ${user.uid} — Add document 'admins/${user.uid}' in Firestore Console to grant admin access.`
        );
        setLoading(false);
        return;
      }

      onLoginSuccess(user);
    } catch (err: any) {
      console.error('Google Sign-In Error:', err);
      if (err.code !== 'auth/popup-closed-by-user') {
        setError(err.message || 'Failed to sign in with Google.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-brand-icon">𝕏</div>
        <h2>X Administrator Portal</h2>
        <p>Sign in with your authorized administrator Google account to moderate posts, manage users, and view community AI insights.</p>

        <button
          className="google-signin-btn"
          onClick={handleGoogleSignIn}
          disabled={loading}
        >
          <svg width="18" height="18" viewBox="0 0 18 18">
            <path
              fill="#4285F4"
              d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.874 2.684-6.616z"
            />
            <path
              fill="#34A853"
              d="M9 18c2.43 0 4.467-.806 5.956-2.184l-2.908-2.258c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332C2.438 15.983 5.482 18 9 18z"
            />
            <path
              fill="#FBBC05"
              d="M3.964 10.707c-.18-.54-.282-1.117-.282-1.707s.102-1.167.282-1.707V4.961H.957C.347 6.173 0 7.548 0 9s.347 2.827.957 4.039l3.007-2.332z"
            />
            <path
              fill="#EA4335"
              d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0 5.482 0 2.438 2.017.957 4.961L3.964 7.293C4.672 5.166 6.656 3.58 9 3.58z"
            />
          </svg>
          {loading ? 'Authenticating...' : 'Sign in with Google'}
        </button>

        {error && <div className="login-error">{error}</div>}
      </div>
    </div>
  );
}
