# Harbor — Production Readiness & Roadmap TODO

A prioritized, actionable checklist taking Harbor from its design-complete state to a fully configured, production-ready release with Firebase and live AI.

---

## 📌 Phase 1: Firebase Configuration & First Live Run

The data models, security rules, and Firebase modular SDK code are ready.

### 1.1 Authentication & Google Sign-In
- [ ] **Enable Email/Password Provider**:
  - In Firebase Console > Authentication > Sign-in method, enable **Email/Password**.
- [x] **Extract Android Keystore Fingerprints**:
  - *Extracted via `cd android; .\gradlew signingReport`:*
    - **SHA-1 (Debug)**: `5E:8F:16:06:2E:A3:CD:2C:4A:0D:54:78:76:BA:A6:F3:8C:AB:F6:25`
    - **SHA-256 (Debug)**: `FA:C6:17:45:DC:09:03:78:6F:B9:ED:E6:2A:96:2B:39:9F:73:48:F0:BB:6F:89:9B:83:32:66:75:91:03:3B:9C`
- [ ] **Add Fingerprints to Firebase**:
  - Firebase Console > Project Settings > General > Your Apps > `com.harbor`.
  - Add both SHA-1 and SHA-256 fingerprints copied above.
- [ ] **Enable Google Sign-In**:
  - Authentication > Sign-in method > Add new provider > **Google**.
  - Set project support email and save (generates the Web OAuth client).
- [ ] **Update Client Config Files**:
  - [ ] Download updated `google-services.json` and replace `android/app/google-services.json` (ensure `oauth_client` is populated).
  - [ ] Download updated `GoogleService-Info.plist` and replace `ios/Harbor/GoogleService-Info.plist`.
- [ ] **Set `webClientId` in Auth Code**:
  - Open `src/services/auth.ts`.
  - Uncomment and insert the Web Client ID into `GoogleSignin.configure({ webClientId: '...' })`.

### 1.2 Firestore & Storage Deployment
- [x] **Create Firestore Database**:
  - Created `(default)` database on project `harbor-rn-2026`.
- [ ] **Enable Cloud Storage**:
  - In Firebase Console > Storage > click **Get Started** (Blaze plan required for Storage bucket).
  - Once initialized, run: `npx firebase-tools deploy --only storage` (rules in `storage.rules` are already authored and validated).
- [x] **Deploy Rules and Indexes**:
  - Firestore security rules (posts, likes, comments, activity, chats, friends, friendRequests, stories) and composite indexes deployed successfully via Firebase CLI.
- [x] **Verify Index Status**:
  - Indexes for `posts` and `likes` deployed.

### 1.3 Flip App to Live Backend
- [x] In `src/config.ts`, changed to:
  ```ts
  export const DEMO_MODE = false;
  ```
- [ ] Clean and rebuild the app:
  ```powershell
  npx react-native run-android
  ```

---

## 🚀 Phase 2: Core Flows Verification (Onboarding, Auth & Homefeed CRUD)

Verify all core user flows against the live Firebase backend.

### 2.1 Onboarding & Authentication
- [ ] **Onboarding Screen**:
  - Verify swipe gesture responsiveness, pager dot animation, and Skip / Next / Get Started buttons.
  - Verify layout on small/compact screens.
- [ ] **User Registration**:
  - Create an account with Full Name, Email, 8+ character password, and terms acceptance.
  - Check live password strength meter.
  - Verify new user appears in **Firebase Auth** and `users/{uid}` document is created in **Firestore**.
- [ ] **User Login**:
  - Test valid email/password login.
  - Test error messages (invalid email, wrong password).
  - Test "Forgot password?" reset email delivery.
  - Test "Continue with Google" sign-in flow.
- [ ] **Session Persistence**:
  - Restart the app and verify the user remains authenticated on the Home feed.

### 2.2 Homefeed CRUD & Social Interactions
- [ ] **Create Post**:
  - Create a text-only post; verify realtime appearance in feed.
  - Create a post with an image (from gallery/camera); verify upload progress bar animation.
  - Confirm file is stored in Cloud Storage (`posts/{uid}/{postId}.jpg`) and post document is in `posts/{postId}`.
  - Verify `postsCount` increments on `users/{uid}`.
- [ ] **Read Post & Feed**:
  - Verify realtime listening on feed changes.
  - Test pull-to-refresh (`refreshFeed`).
  - Test pagination / infinite scroll (`loadMore`).
  - Tap post to open Post Detail view (`PostScreen`).
- [ ] **Likes & Comments**:
  - Double-tap post to trigger heart burst animation.
  - Tap heart icon to like/unlike; verify `likeCount` updates transactionally.
  - Write a comment; verify optimistic rendering and `commentCount` increment.
- [ ] **Delete Post**:
  - Tap "..." on own post; confirm deletion prompt.
  - Verify post is removed from feed, Firestore doc is deleted, and Cloud Storage image is cleaned up.
- [ ] *(Optional Feature)* **Edit Post**:
  - Current design treats posts as immutable. If editing post text is required, implement `editPost` sheet and Firestore `updateDoc` method.

---

## 🤖 Phase 3: AI Backend Integration (Overview, Suggestions & Chat)

Transition from simulated demo delay to live AI backend.

### 3.1 AI Cloud Function / Secure API Proxy
- [x] **Secure Architecture**: API keys kept strictly off mobile client.
- [x] **Firebase Cloud Function (`aiComplete`)**:
  - Created in `functions/src/index.ts` using Firebase Functions v6.
  - Supports Gemini (default) and Claude proxies with authenticated user validation (`context.auth.uid`).
  - Added build scripts and TypeScript configuration (`functions/package.json`, `functions/tsconfig.json`). Tested compilation clean.
  - Configured codebase in `firebase.json` for easy deployment via `firebase deploy --only functions`.
- [x] **Wire `complete()` in `src/services/ai.ts`**:
  - Calls `aiComplete` via `@react-native-firebase/functions` when not in `DEMO_MODE`.

### 3.2 AI Feature Auditing & Verification
- [ ] **Deploy Cloud Function**:
  - Set secret key: `npx firebase-tools functions:secrets:set GEMINI_API_KEY`
  - Deploy: `npx firebase-tools deploy --only functions`
- [ ] **Harbor Brief (AI Overview)**:
  - Feed Brief Card and Brief Tab ("Today" / "This week").
  - Verify 3-sentence summary of friends' recent posts generated via `generateBrief()`.
- [ ] **Ask Harbor & Suggestions**:
  - Verify suggestion chips in Brief tab populate and can be tapped.
  - Verify natural language questions about friend updates return contextual answers via `askHarbor()`.
- [ ] **Comment Summaries**:
  - On Post Detail (`PostScreen`), test "Comment summary" generation via `summarizeComments()`.
- [ ] **Polish with Harbor (Post Creation)**:
  - In `NewPostScreen`, test "Clearer", "Warmer", and "Shorter" tone rewrites via `polishPost()`.
  - Test "Undo AI edit" capability.

---

## 💬 Phase 4: Social Features & Chat Persistence

Realtime Firestore collections for chat, friends, and activity.

- [x] **Direct Messages & Chat**:
  - Created Firestore collection `chats/{chatId}` and subcollection `chats/{chatId}/messages` with deterministic IDs.
  - Security rules deployed to Firestore.
  - Created `src/services/backend/chat.ts` for chat subscriptions, message queries, message sending, and read receipts.
  - Replaced mock chat storage in `src/state/SocialContext.tsx` with realtime Firestore `onSnapshot` listeners and live message dispatch.
  - Updated `UserProfileScreen` and `MessagesScreen` to allow starting chats with any user.
- [x] **Friends & Friend Requests**:
  - Created `users/{uid}/friends` and `friendRequests` security rules and deployed.
  - Implemented `src/services/backend/social.ts` (`subscribeFriends`, `subscribeFriendRequests`, `sendFriendRequest`, `cancelFriendRequest`, `acceptFriendRequest`, `declineFriendRequest`, `removeFriend`).
  - Wired into `SocialContext.tsx` with optimistic UI and live synchronization.
- [x] **Live Notifications**:
  - Connected `useNotifications()` to read from `users/{uid}/activity` via `StoreContext` in live Firebase mode.
  - Connected `markAllRead` to `store.markAllRead()`.
- [x] **Stories**:
  - Added security rules for stories metadata (`stories/{storyId}`) in `firestore.rules` (deployed).
  - Added security rules for story images (`stories/{uid}/{fileName}`) in `storage.rules`.

---

## 📱 Phase 5: Production Release Preparation & UI Polish

- [x] **Production UI Polish & Edge-to-Edge Design**:
  - **Android Edge-to-Edge Navigation**: Configured `android:statusBarColor` and `android:navigationBarColor` to `@android:color/transparent` in `android/app/src/main/res/values/styles.xml` and wired dynamic `barStyle` switching in `App.tsx` (`AppStatusBar`) for seamless immersion behind status & navigation bars.
  - **Branded Startup Experience**: Replaced bare activity indicator in `BootScreen` (`App.tsx`) with an animated pulsing Harbor SVG mark, bold Geist wordmark, and tagline ("Stay close to your people").
  - **Comment Empty State**: Added `EmptyState` in `PostScreen.tsx` ("No comments yet. Be the first to share your thoughts on this post.") with an immediate "Write a comment" action that focuses the composer.
  - **Live Composer Character Counter**: Added a dynamic character counter (`text.length/MAX`) to `NewPostScreen.tsx` with progressive warning/danger color transitions as users near the 500-character limit.
  - **Direct Search & Messaging UX**: Wired the `note-pencil` button in `MessagesScreen.tsx` to automatically focus the search bar with haptic feedback and helper toast.
  - **Empty States & Accessibility**: Polished empty and error fallbacks across `NotificationsScreen.tsx`, `MessagesScreen.tsx`, and `HomeScreen.tsx`.
- [x] **Android Production Signing**:
  - Configured `signingConfigs.release` in `android/app/build.gradle` using environment variables / gradle properties (`HARBOR_UPLOAD_STORE_FILE`, `HARBOR_UPLOAD_STORE_PASSWORD`, etc.).
- [x] **iOS Configuration (Mac)**:
  - Added `CFBundleURLSchemes` for Google Sign-In in `ios/Harbor/Info.plist`.
  - Verified `NSCameraUsageDescription` and `NSPhotoLibraryUsageDescription` in `Info.plist`.
- [ ] **Firebase App Check**:
  - Optional hardening: integrate `@react-native-firebase/app-check` (Play Integrity for Android, App Attest for iOS) to guard backend endpoints against unauthorized clients.
- [ ] **Final Smoke Testing**:
  - Run the application on device/emulator (`npx react-native run-android`).
  - Test edge-to-edge layout, keyboard navigation, and toast bars across Android gesture/3-button navigation and iOS notch/island devices.
