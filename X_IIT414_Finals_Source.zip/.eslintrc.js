module.exports = {
  root: true,
  extends: '@react-native',
  ignorePatterns: [
    'design-import/**',
    'functions/**',
    'android/**',
    'ios/**',
    'node_modules/**',
  ],
};
